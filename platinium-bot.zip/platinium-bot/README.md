# 🔱 PLATINIUM Telegram Bot

Live trading intelligence delivered to Telegram.
Signals, edge score, astro alerts, daily P&L summary.

---

## STEP 1 — Get your bot token

1. Open Telegram → search **@BotFather**
2. Send `/newbot`
3. Choose a name: `PLATINIUM`
4. Choose a username: `platinium_mybot` (must end in `bot`)
5. BotFather gives you a token like: `7234567890:AAExxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`
6. **Save that token**

## STEP 2 — Get your chat ID

1. Open Telegram → search **@userinfobot**
2. Send `/start`
3. It replies with your ID like: `Your id: 123456789`
4. **Save that ID**

---

## DEPLOY OPTION A — VPS / Linux Server (recommended)

```bash
# 1. Clone / upload the platinium-bot folder to your server
scp -r platinium-bot/ user@yourserver:~/

# 2. SSH into server
ssh user@yourserver

# 3. Install Python 3.11+
sudo apt update && sudo apt install python3 python3-pip python3-venv -y

# 4. Create virtual environment
cd platinium-bot
python3 -m venv venv
source venv/bin/activate

# 5. Install dependencies
pip install -r requirements.txt

# 6. Set up environment
cp .env.example .env
nano .env    # fill in your token and chat ID

# 7. Test run
python bot.py

# 8. Run forever with systemd (auto-restart on crash/reboot)
sudo nano /etc/systemd/system/platinium.service
```

Paste this into the service file:
```ini
[Unit]
Description=PLATINIUM Trading Bot
After=network.target

[Service]
Type=simple
User=YOUR_USERNAME
WorkingDirectory=/home/YOUR_USERNAME/platinium-bot
EnvironmentFile=/home/YOUR_USERNAME/platinium-bot/.env
ExecStart=/home/YOUR_USERNAME/platinium-bot/venv/bin/python bot.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

```bash
# Enable and start
sudo systemctl daemon-reload
sudo systemctl enable platinium
sudo systemctl start platinium

# Check it's running
sudo systemctl status platinium

# View logs live
sudo journalctl -u platinium -f
```

---

## DEPLOY OPTION B — Railway (free cloud, easiest)

1. Go to **railway.app** → New Project → Deploy from GitHub
2. Push this folder to a GitHub repo
3. In Railway: Add variables:
   - `TELEGRAM_BOT_TOKEN` = your token
   - `TELEGRAM_CHAT_ID` = your chat ID
4. Railway auto-detects Python and runs `bot.py`
5. Done — runs 24/7 free tier

---

## DEPLOY OPTION C — Render (free cloud)

1. Go to **render.com** → New → Web Service
2. Connect your GitHub repo
3. Build command: `pip install -r requirements.txt`
4. Start command: `python bot.py`
5. Add environment variables (same as above)
6. Deploy — free plan, stays alive

---

## DEPLOY OPTION D — Your Mac/PC (always on)

```bash
# 1. Install Python from python.org if needed

# 2. Navigate to folder
cd platinium-bot

# 3. Install dependencies
pip3 install -r requirements.txt

# 4. Set up .env
cp .env.example .env
# Edit .env with your token and chat ID

# 5. Run
python3 bot.py

# To keep running after terminal closes (Mac):
nohup python3 bot.py &
```

---

## BOT COMMANDS

| Command | Description |
|---------|-------------|
| `/start` | Start bot + subscribe to alerts |
| `/signal` | Get current best signal |
| `/edge` | Edge score and database stats |
| `/equity` | Simulation P&L ($100 → live) |
| `/astro` | Current astro conditions |
| `/summary` | Full daily summary |
| `/search BTC` | Analyze any coin |
| `/status` | Bot health check |
| `/stop` | Unsubscribe from alerts |

---

## WHAT THE BOT SENDS YOU

### 🔥 Signal Alert (when pattern fires)
```
🟢 LONG — Wyckoff Spring + New Moon

📊 Category: COMBO
🎯 Accuracy: 72%
⚡ Confidence: 78/100
📈 Avg EV: +1.8%

💰 Entry: $70,432
🛑 Stop Loss: $68,319
🎯 Target: $74,658
⚖️ R:R: 2.1:1
🔢 Leverage: 6×
💼 Size: 14% of balance

🧠 Why:
  • 🌒 Wax Crescent — waxing bull cycle
  • RSI 28 — deep oversold, demand zone
  • Wick rejection — liquidity grab
```

### 📊 Edge Score Update (crossing levels)
```
🟠 Edge Score: 50/100 — FORMING
░░░░░████░ 50%

📦 Patterns in DB: 38
👁 Total observations: 842
🏆 Elite patterns (≥70%): 6
✅ Sim win rate: 58%
```

### 🌕 Astro Alert
```
🌕 Full Moon!
Full Moon — reversal risk elevated. Tighten stops.
```

### 📋 Daily Summary (08:00 UTC)
Full P&L, win rate, best pattern, astro conditions.

---

## CONFIGURATION

Edit `.env` to customize:

```bash
MIN_CONFIDENCE=62    # Only alert on high-confidence signals (50-95)
MIN_ACCURACY=60      # Minimum pattern accuracy to alert
EQUITY_ALERT_PCT=5   # Alert every 5% balance change
TICK_INTERVAL=30     # Engine runs every 30 seconds
DAILY_HOUR=8         # Daily summary at 08:00 UTC
```

---

## FILE STRUCTURE

```
platinium-bot/
├── bot.py          # Telegram bot — all commands, alerts, scheduling
├── engine.py       # Full trading engine — astro, indicators, patterns
├── requirements.txt
├── .env.example    # Config template
└── README.md
```

---

## TROUBLESHOOTING

**Bot doesn't respond:**
- Check token in .env (no spaces, no quotes)
- Make sure bot is running: `systemctl status platinium`

**No alerts coming:**
- Send `/start` to the bot first to subscribe
- Check MIN_CONFIDENCE isn't too high
- Use `/status` to verify engine is ticking

**API errors:**
- Bot falls back to simulated price if Binance is unreachable
- Alerts still work, just on simulated data

**Mercury Retrograde:**
- Bot automatically warns you and reduces signal confidence
- This is real ephemeris calculation, not random

---

Built with PLATINIUM engine — 41 patterns, real Binance data, real astro calculations.
